# Calculator-using-HTML-CSS-and-JavaScript

## Screenshot

<img width="507" alt="screenshot" src="https://user-images.githubusercontent.com/34116562/54217627-00672b80-4512-11e9-8670-63cbed7a11bb.png">
